#Requires -Version 5.1
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

# Function Declarations **************************************************************************

function Write-Info {
    param([string]$Message)
    Write-Host $Message -ForegroundColor Cyan
}

function Write-Success {
    param([string]$Message)
    Write-Host $Message -ForegroundColor Green
}

function Write-Warn {
    param([string]$Message)
    Write-Host $Message -ForegroundColor Yellow
}

function Write-Error {
    param([string]$Message)
    Write-Host $Message -ForegroundColor Red
}

function Disable-Warnings {
    # Disable PSNativeCommandUseErrorActionPreference
    Write-Info "`nDisabling PowerShell Warnings..."
    $PSNativeCommandUseErrorActionPreference = $false

    Write-Info "Disabling Node.js Warnings..."
    $env:NODE_NO_WARNINGS = '1'

    # SSL and TLS Changes (to hopefully fix self-signed cert issue)
    Write-Info "Adjusting Self-Signed Certificate Settings..."
    Write-Host "Making SSL changes..."
    npm config set strict-ssl false

    Write-Host "Making TLS changes..."
    $env:NODE_TLS_REJECT_UNAUTHORIZED = 0

    # Disable Warning DEP0169
    Write-Info "Disabling Node.js Deprecation Warning..."
    $env:NODE_OPTIONS="--disable-warning=DEP0169"
    Write-Info ""
}

function Enable-Warnings {
    # Re-enabling SSL and TLS Changes
    Write-Info "`nAdjusting Self-Signed Certificate Settings..."
    Write-Host "Making SSL changes..."
    npm config set strict-ssl true

    Write-Host "Making TLS changes..."
    $env:NODE_TLS_REJECT_UNAUTHORIZED = 1

    Write-Info "`nRe-enabling Node.js Warnings..."
    $env:NODE_NO_WARNINGS = '0'

    # Re-enable PSNativeCommandUseErrorActionPreference
    Write-Info "Re-enabling PowerShell Warnings..."
    $PSNativeCommandUseErrorActionPreference = $true
}

function Update-LiteralText {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Pattern,
        [Parameter(Mandatory = $true)][string]$Replacement,
        [switch]$IgnoreCase
    )

    $content = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    $options = [System.Text.RegularExpressions.RegexOptions]::None
    if ($IgnoreCase) {
        $options = $options -bor [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    }

    $escapedPattern = [System.Text.RegularExpressions.Regex]::Escape($Pattern)
    $updated = [System.Text.RegularExpressions.Regex]::Replace(
        $content,
        $escapedPattern,
        [System.Text.RegularExpressions.MatchEvaluator]{ param($m) $Replacement },
        $options
    )

    Set-Content -LiteralPath $Path -Value $updated -Encoding UTF8
}

function Backup-Settings {
    param(
        [Parameter(Mandatory = $true)][string]$VsCodePath,
        [Parameter(Mandatory = $true)][string]$BackupPath
    )

    if ((Test-Path $VsCodePath)) {
        Write-Info "`nBacking up current VS Code settings..."

        Copy-Item -LiteralPath $VsCodePath -Destination $BackupPath -Force

        Write-Success "Settings file has been backed up."
        Write-Host "Location: $BackupPath"
    }
}

function Backup-Extensions {
    param(
        [Parameter(Mandatory = $true)][string]$BackupPath
    )

    Write-Info "`nBacking up current VS Code extensions..."
    code --list-extensions > $BackupPath

    Write-Success "Extensions list has been backed up."
    Write-Host "Location: $BackupPath"
}

function Backup-Snippets {
    param(
        [Parameter(Mandatory = $true)][string]$VsCodeDir,
        [Parameter(Mandatory = $true)][string]$BackupDir
    )

    if ((Test-Path $VsCodeDir)) {
        Write-Info "`nBacking up current VS Code snippets..."

        # Create Snippets Backup Directory (if it doesn't exist)
        if (-not (Test-Path -Path $BackupDir)) {
            New-Item -Path $BackupDir -ItemType Directory | Out-Null
            Write-Info "Created Snippets Backup directory"
        }

        # Copy contents of VS Code snippets folder to the Snippets Backup folder
        Copy-Item -Path "$VsCodeDir\*" -Destination $BackupDir -Recurse -Force

        Write-Success "Snippet files have been backed up."
        Write-Host "Snippets Backup Location: $BackupDir"
    }
}

function Update-Settings {
    param(
        [Parameter(Mandatory = $true)][string]$VsCodePath
    )

    # Modify default VS Code Settings to enable SSL and Certificate Changes **************************
    Write-Host "`nAdjusting SSL and Certificates settings for VS Code"

    # Ensure the file exists
    if (-not (Test-Path $VsCodePath)) {
        '{}' | Set-Content $VsCodePath -Encoding utf8
    }

    # Load existing JSON from settings file
    try {
        $jsonText = Get-Content $VsCodePath -Raw
        if ([string]::IsNullOrWhiteSpace($jsonText)) {
            $json = [PSCustomObject]@{}
        }
        else {
            $json = $jsonText | ConvertFrom-Json
        }
    }
    catch {
        Write-Error "Invalid JSON detected."
        Write-Info "Initializing empty settings.json..."
        $json = [PSCustomObject]@{}
    }

    # Track whether changes were made
    $updated = $false

    # Add the http.proxyStrictSSL setting
    if (-not ($json.PSObject.Properties.Name -contains "http.proxyStrictSSL")) {
        $json | Add-Member -NotePropertyName "http.proxyStrictSSL" -NotePropertyValue $false
        $updated = $true
    }
    elseif ($json."http.proxyStrictSSL" -eq $true) {
        $json."http.proxyStrictSSL" = $false
        $updated = $true
    }

    # Add http.systemCertificates setting
    if (-not ($json.PSObject.Properties.Name -contains "http.systemCertificates")) {
        $json | Add-Member -NotePropertyName "http.systemCertificates" -NotePropertyValue $true
        $updated = $true
    }
    elseif ($json."http.systemCertificates" -eq $false) {
        $json."http.systemCertificates" = $true
        $updated = $true
    }

    # Save only if changes were made
    if ($updated) {
        $json | ConvertTo-Json -Depth 100 | Set-Content $VsCodePath -Encoding utf8
        Write-Success "VS Code settings.json updated successfully."
    }
    else {
        Write-Success "No changes to the VS Code settings.json file were needed."
    }
}

function Update-MultipleEmailVariants {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Replacement
    )

    $content = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    $pattern = '(?i)' + [System.Text.RegularExpressions.Regex]::Escape('Seth.Walters@FISGLOBAL.COM') + '|' + [System.Text.RegularExpressions.Regex]::Escape('seth.walters@fisglobal.com')
    $updated = [System.Text.RegularExpressions.Regex]::Replace(
        $content,
        $pattern,
        [System.Text.RegularExpressions.MatchEvaluator]{ param($m) $Replacement }
    )
    Set-Content -LiteralPath $Path -Value $updated -Encoding UTF8
}

function Update-Paths {
    # Re-read PATH variables after additional app installations
    # This way we don't have to re-open the shell
    Write-Host "`nRe-reading PATH variables..."
    $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
    $userPath    = [Environment]::GetEnvironmentVariable("Path", "User")
    $env:Path    = "$machinePath;$userPath"
}

<#
    Check if VS Code is installed
    If installed, then checks for updates
    If not installed, then installs
#>
function Install-VsCode {
  $packageId = 'Microsoft.VisualStudioCode'

  Write-Info "`nChecking for $packageId..."

  $vsCodeExists = $false

  # Check whether VS Code is already installed
  try {
      $null = & code --version 2>$null
      if ($LASTEXITCODE -eq 0) { $vsCodeExists = $true }
  } catch {}

  if ($vsCodeExists) {
        Write-Success "`n$packageId is already installed: $(code --version)"
        Write-Info "`nUpdating VS Code..."

        winget upgrade `
        --id $packageId `
        --silent `
        --scope user `
        --accept-package-agreements `
        --accept-source-agreements
    }
    else {
        Write-Warn "`n$packageId not found."
        Write-Info "Installing VS Code..."

        winget install `
        --id $packageId `
        --silent `
        --scope user `
        --accept-package-agreements `
        --accept-source-agreements
    }
}

<#
    Check if Node.js / npm are installed
    If installed, then checks for updates
    If not installed, then installs
#>
function Install-Nodejs {
    $packageId = 'OpenJS.NodeJS'

    Write-Info "`nChecking for $packageId (mainly so we can utilize npm)..."

    $nodeExists = $false
    $npmExists  = $false

    # Check whether Node.js is already installed
    try {
        $null = & node --version 2>$null
        if ($LASTEXITCODE -eq 0) { $nodeExists = $true }
    } catch {}

    # Check whether npm is already installed
    try {
        $null = & npm --version 2>$null
        if ($LASTEXITCODE -eq 0) { $npmExists = $true }
    } catch {}

    if ($nodeExists -and $npmExists) {
        Write-Success "`nNode.js is already installed: $(node --version)"
        Write-Success "npm is already installed: $(npm --version)"
        Write-Info "`nUpdating Node.js/npm..."

        winget upgrade `
        --id $packageId `
        --silent `
        --scope user `
        --accept-package-agreements `
        --accept-source-agreements
    }
    else {
        Write-Warn "`nNode.js/npm not found."
        Write-Info "Installing Node.js..."

        winget install `
        --id $packageId `
        --silent `
        --scope user `
        --accept-package-agreements `
        --accept-source-agreements
    }
}

<#
    Check if Git is installed
    If installed, then checks for updates
    If not installed, then installs
#>
function Install-Git {
  $packageId = 'Git.Git'

  Write-Info "`nChecking for $packageId..."

  $gitExists = $false

  # Check whether Git is already installed
  try {
      $null = & git --version 2>$null
      if ($LASTEXITCODE -eq 0) { $gitExists = $true }
  } catch {}

  if ($gitExists) {
        Write-Success "`n$packageId is already installed: $(git --version)"
        Write-Info "`nUpdating Git..."

        winget upgrade `
        --id $packageId `
        --silent `
        --scope user `
        --accept-package-agreements `
        --accept-source-agreements
    }
    else {
        Write-Warn "`n$packageId not found."
        Write-Info "Installing Git..."

        winget install `
        --id $packageId `
        --silent `
        --scope user `
        --accept-package-agreements `
        --accept-source-agreements
    }
}

function Enable-GCM {
  Write-Info "`nChecking for Git Credential Manager (GCM)..."

  $gcmExists = $false

  # Check whether Git Credential Manager Core is already installed
  try {
      $null = & git credential-manager --version 2>$null
      if ($LASTEXITCODE -eq 0) { $gcmExists = $true }
  } catch {}

  if ($gcmExists) {
        Write-Success "`nGCM is already installed: $(git credential-manager --version)"
  } else {}

  # Enable GCM
  git config --global credential.helper manager-core

  # Verify GCM is enabled
  git config --global credential.helper

  Write-Success "GCM is enabled"
}

# Install local extension from .vsix files
function Install-LocalExtensions {
    param(
        [Parameter(Mandatory = $true)][string]$Path
    )

    Write-Info "`nGetting list of local extensions to install..."

    # Get all .vsix files
    $ExtensionFiles = Get-ChildItem -Path $Path -Filter *.vsix -File

    if (-not $ExtensionFiles) {
        Write-Warn "No .vsix files were found in: $Path"
        exit 0
    }

    Write-Success "`nFound $($ExtensionFiles.Count) .vsix file(s) in: $Path"

    foreach ($extension in $ExtensionFiles) {
        Write-Info "`nInstalling: $($extension.Name)"

        try {
            & code --install-extension $extension.FullName --force

            if ($LASTEXITCODE -eq 0) {
                Write-Success "Successfully installed: $($extension.Name)"
            }
            else {
                Write-Warn "Failed to install: $($extension.Name) (Exit Code: $LASTEXITCODE)"
            }
        }
        catch {
            Write-Error "Error installing $($extension.Name): $_"
        }
    }
}

# Main Script Start ******************************************************************************
Clear-Host

# Install VS Code
Install-VsCode

# Install Node.js / npm
Install-Nodejs

# Install Git
Install-Git

# Update Path Variables
Update-Paths

# Enable Git Credential Manager
Enable-GCM

# Disable PowerShell / npm warnings
Disable-Warnings

# Set Path Variables *****************************************************************************
Write-Info "`nSetting required directory and file paths..."
$ScriptDir                = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }
$BackupDir                = Join-Path $ScriptDir 'backup'
$SnippetsBackupDir        = Join-Path $BackupDir 'snippets'
$ExtensionsDir            = Join-Path $ScriptDir 'extensions'
$SnippetsDir              = Join-Path $ScriptDir 'snippets'
$SqlSnippetsPath          = Join-Path $SnippetsDir 'sql.json'
$GlobalSnippetsPath       = Join-Path $SnippetsDir 'Global Snippets.code-snippets'
$SettingsPath             = Join-Path $ScriptDir 'settings.json'
$SettingsBackupPath       = Join-Path $BackupDir 'settings_backup.json'
$ExtensionsPath           = Join-Path $ExtensionsDir 'extensions.txt'
$ExtensionsBackupPath     = Join-Path $BackupDir 'extensions_backup.txt'
$UninstallExtensionsPath  = Join-Path $ExtensionsDir 'uninstall_extensions.txt'
$VsCodeUserDir            = Join-Path $env:APPDATA 'Code\User'
$VsCodeSettingsPath       = Join-Path $VsCodeUserDir 'settings.json'
$VsCodeSnippetsDir        = Join-Path $VsCodeUserDir 'snippets'
$VsCodeGlobalSnippetsPath = Join-Path $VsCodeSnippetsDir 'Global Snippets.code-snippets'
$VsCodeSqlSnippetsPath    = Join-Path $VsCodeSnippetsDir 'sql.json'

# Check for Required Directories
Write-Info "`nChecking if required directories exist..."
foreach ($requiredDir in @($ExtensionsDir, $VsCodeUserDir, $VsCodeSnippetsDir, $SnippetsDir)) {
    if (-not (Test-Path -LiteralPath $requiredDir -PathType Container)) {
        throw "Required directory not found: $requiredDir"
    }
}

# Check for Required Files
Write-Info "`nChecking if required files exist..."
foreach ($requiredFile in @($SqlSnippetsPath, $GlobalSnippetsPath, $SettingsPath, $ExtensionsPath, $UninstallExtensionsPath)) {
    if (-not (Test-Path -LiteralPath $requiredFile)) {
        throw "Required file not found: $requiredFile"
    }
}

# Create Backup Directory (if it doesn't exist)
if (-not (Test-Path -Path $BackupDir)) {
    Write-Info "`nCreating Backup directory..."
    New-Item -Path $BackupDir -ItemType Directory | Out-Null
    Write-Host "Backup directory: $BackupDir"
}

# Backup current VS Code Snippets
Backup-Snippets -VsCodeDir $VsCodeSnippetsDir -BackupDir $SnippetsBackupDir

# Backup current VS Code Settings
Backup-Settings -VsCodePath $VsCodeSettingsPath -BackupPath $SettingsBackupPath

# Backup list of current VS Code Extensions
Backup-Extensions -BackupPath $ExtensionsBackupPath

# Modify default VS Code Settings to enable SSL and Certificate Changes
Update-Settings -VsCodePath $VsCodeSettingsPath

# Ping User (to let them know information is needed)
[console]::beep(1400, 200)

# Get required information from user
Write-Info "`nPlease enter the following information:"
$FullName     = Read-Host '1. Full Name (for example, Luke Skywalker)'
$EmailAddress = Read-Host '2. Email Address (for example, Luke.Skywalker@FISGLOBAL.COM)'
$EmployeeID   = Read-Host '3. Employee ID (for example, e9999999)'

Write-Info "`nThe SQL snippets file, Global Snippets file, and Settings file will now be updated with the values you entered."

# Replace default values in files
Update-LiteralText -Path $SqlSnippetsPath -Pattern 'Seth Walters' -Replacement $FullName
Update-LiteralText -Path $GlobalSnippetsPath -Pattern 'Seth Walters' -Replacement $FullName
Update-MultipleEmailVariants -Path $GlobalSnippetsPath -Replacement $EmailAddress
Update-LiteralText -Path $GlobalSnippetsPath -Pattern 'e5577005' -Replacement $EmployeeID
Update-MultipleEmailVariants -Path $SettingsPath -Replacement $EmailAddress

Write-Success "The files were edited successfully."

Write-Warn "`nThe files are going to be copied to the correct location for VS Code. Any existing file will be replaced."
$continueMove = Read-Host 'Enter Y to continue with copying the files, or N to skip moving them'

if ($continueMove -match '^[Yy]$') {
    if (-not (Test-Path -LiteralPath $VsCodeUserDir)) {
        New-Item -Path $VsCodeUserDir -ItemType Directory -Force | Out-Null
    }
    if (-not (Test-Path -LiteralPath $VsCodeSnippetsDir)) {
        New-Item -Path $VsCodeSnippetsDir -ItemType Directory -Force | Out-Null
    }

    # Copy the Settings and Snippet files
    Copy-Item -LiteralPath $SettingsPath -Destination $VsCodeSettingsPath -Force
    Copy-Item -LiteralPath $GlobalSnippetsPath -Destination $VsCodeGlobalSnippetsPath -Force
    Copy-Item -LiteralPath $SqlSnippetsPath -Destination $VsCodeSqlSnippetsPath -Force

    Write-Success "The files were copied successfully and the changes have been made."
}
elseif ($continueMove -match '^[Nn]$') {
    Write-Warn "File copy was skipped."
}
else {
    Write-Warn "Unrecognized response. File copy was skipped."
}

# Uninstall extensions from the uninstall extensions file
Write-Warn "`nPreparing to uninstall unneeded extensions..."

Get-Content -LiteralPath $UninstallExtensionsPath | ForEach-Object {
    $UnExtensionName = $_.Trim()
    if (-not [string]::IsNullOrWhiteSpace($UnExtensionName)) {
        if (code --list-extensions | Where-Object { $_ -eq $UnExtensionName }) {
            code --uninstall-extension $UnExtensionName
            Write-Success "Removed $UnExtensionName"
        }
        else {
            Write-Info "$UnExtensionName not installed"
        }
    }
}

Write-Warn "`nThe recommended extensions for VS Code will now be installed."
$continueInstall = Read-Host 'Enter Y to continue installing the extensions, or N to skip installing them'

if ($continueInstall -match '^[Yy]$') {
    # Install extensions from the extensions file
    Get-Content -LiteralPath $ExtensionsPath | ForEach-Object {
        $ExtensionName = $_.Trim()
        if (-not [string]::IsNullOrWhiteSpace($ExtensionName)) {
            Write-Info "Installing $ExtensionName"
            code --install-extension $ExtensionName
        }
    }

    # Install local extensions from .vsix files
    Install-LocalExtensions $ExtensionsDir
}
elseif ($continueInstall -match '^[Nn]$') {
    Write-Warn "Extension installations were skipped."
}
else {
    Write-Warn "Unrecognized response. Extension installations were skipped."
}

# Re-enable PowerShell and node warnings
Enable-Warnings

# Ping User (to let them know the script is finished)
[console]::beep(1400, 200)

Write-Success "`nWe seem to be all done here. Great job!"
Write-Success "Thanks for setting up VS Code with me! :)"
Write-Host ""

[void](Read-Host 'Press Enter to close this script and open VS Code')
Start-Process 'code'
exit