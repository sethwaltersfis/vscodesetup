#Requires -Version 5.1
[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'

function Write-Info {
    param([string]$Message)
    Write-Host $Message -ForegroundColor Cyan
}

function Write-Success {
    param([string]$Message)
    Write-Host $Message -ForegroundColor Green
}

function Write-Warn {
    param([string]$Message)
    Write-Host $Message -ForegroundColor Yellow
}

function Replace-LiteralText {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Pattern,
        [Parameter(Mandatory = $true)][string]$Replacement,
        [switch]$IgnoreCase
    )

    $content = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    $options = [System.Text.RegularExpressions.RegexOptions]::None
    if ($IgnoreCase) {
        $options = $options -bor [System.Text.RegularExpressions.RegexOptions]::IgnoreCase
    }

    $escapedPattern = [System.Text.RegularExpressions.Regex]::Escape($Pattern)
    $updated = [System.Text.RegularExpressions.Regex]::Replace(
        $content,
        $escapedPattern,
        [System.Text.RegularExpressions.MatchEvaluator]{ param($m) $Replacement },
        $options
    )

    Set-Content -LiteralPath $Path -Value $updated -Encoding UTF8
}

function Replace-MultipleEmailVariants {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Replacement
    )

    $content = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    $pattern = '(?i)' + [System.Text.RegularExpressions.Regex]::Escape('Seth.Walters@FISGLOBAL.COM') + '|' + [System.Text.RegularExpressions.Regex]::Escape('seth.walters@fisglobal.com')
    $updated = [System.Text.RegularExpressions.Regex]::Replace(
        $content,
        $pattern,
        [System.Text.RegularExpressions.MatchEvaluator]{ param($m) $Replacement }
    )
    Set-Content -LiteralPath $Path -Value $updated -Encoding UTF8
}

try {
    $ScriptDir = if ($PSScriptRoot) { $PSScriptRoot } else { Split-Path -Parent $MyInvocation.MyCommand.Path }

    $SqlSnippetsPath = Join-Path $ScriptDir 'sql.json'
    $GlobalSnippetsPath = Join-Path $ScriptDir 'Global Snippets.code-snippets'
    $SettingsPath = Join-Path $ScriptDir 'settings.json'
    $ExtensionsPath = Join-Path $ScriptDir 'extensions.txt'

    foreach ($requiredFile in @($SqlSnippetsPath, $GlobalSnippetsPath, $SettingsPath, $ExtensionsPath)) {
        if (-not (Test-Path -LiteralPath $requiredFile)) {
            throw "Required file not found: $requiredFile"
        }
    }

    Write-Info 'Please enter the following information.'
    $FullName = Read-Host '1. Full Name (for example, Seth Walters)'
    $EmailAddress = Read-Host '2. Email Address (for example, Seth.Walters@FISGLOBAL.COM)'
    $EmployeeID = Read-Host '3. Employee ID (for example, e5577005)'

    Write-Host ''
    Write-Info 'The SQL snippets file, Global Snippets file, and Settings file will now be updated with the values you entered.'

    Replace-LiteralText -Path $SqlSnippetsPath -Pattern 'Seth Walters' -Replacement $FullName

    Replace-LiteralText -Path $GlobalSnippetsPath -Pattern 'Seth Walters' -Replacement $FullName
    Replace-MultipleEmailVariants -Path $GlobalSnippetsPath -Replacement $EmailAddress
    Replace-LiteralText -Path $GlobalSnippetsPath -Pattern 'e5577005' -Replacement $EmployeeID

    Replace-MultipleEmailVariants -Path $SettingsPath -Replacement $EmailAddress

    Write-Success 'The files were edited successfully.'
    Write-Host ''

    Write-Warn 'The files are going to be copied to the correct location for Visual Studio Code. Any existing file will be replaced.'
    $continueMove = Read-Host 'Enter Y to continue with copying the files, or N to skip moving them'

    if ($continueMove -match '^[Yy]$') {
        $VsCodeUserDir = Join-Path $env:APPDATA 'Code\User'
        $VsCodeSnippetsDir = Join-Path $VsCodeUserDir 'snippets'

        if (-not (Test-Path -LiteralPath $VsCodeUserDir)) {
            New-Item -Path $VsCodeUserDir -ItemType Directory -Force | Out-Null
        }
        if (-not (Test-Path -LiteralPath $VsCodeSnippetsDir)) {
            New-Item -Path $VsCodeSnippetsDir -ItemType Directory -Force | Out-Null
        }

        Copy-Item -LiteralPath $SettingsPath -Destination (Join-Path $VsCodeUserDir 'settings.json') -Force
        Copy-Item -LiteralPath $GlobalSnippetsPath -Destination (Join-Path $VsCodeSnippetsDir 'Global Snippets.code-snippets') -Force
        Copy-Item -LiteralPath $SqlSnippetsPath -Destination (Join-Path $VsCodeSnippetsDir 'sql.json') -Force

        Write-Success 'The files were copied successfully and the changes have been made.'
    }
    elseif ($continueMove -match '^[Nn]$') {
        Write-Warn 'File copy was skipped.'
    }
    else {
        Write-Warn 'Unrecognized response. File copy was skipped.'
    }

    Write-Host ''
    Write-Info 'Visual Studio Code extensions will now be installed.'

    if (-not (Get-Command code -ErrorAction SilentlyContinue)) {
        Write-Warn 'The VS Code command-line tool (code) was not found in PATH. Extension installation may fail, and opening Visual Studio Code at the end may also fail until the command is available.'
    }

    Get-Content -LiteralPath $ExtensionsPath | ForEach-Object {
        $extension = $_.Trim()
        if (-not [string]::IsNullOrWhiteSpace($extension)) {
            Write-Host "Installing extension: $extension"
            code --install-extension $extension
        }
    }

    Write-Host ''
    Write-Host "Installing SQL Field List Formatter extension"
    code --install-extension .\sql-field-list-formatter-0.5.0.vsix

    Write-Host ''
    Write-Success 'Everything is done.'
    [void](Read-Host 'Press Enter to close this script and open Visual Studio Code')
    Start-Process 'code'
    exit
}
catch {
    Write-Host ''
    Write-Host "An error occurred: $($_.Exception.Message)" -ForegroundColor Red
    [void](Read-Host 'Press Enter to close this script')
    exit 1
}
